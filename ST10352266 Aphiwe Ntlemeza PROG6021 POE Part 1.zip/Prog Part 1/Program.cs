﻿using System;

public class Recipe //Declarations
{
    public string NameOfRecipe;
    public int NumberOfIngredients;
    public string[] NameOfIngredient;
    public double[] Quantity;
    public string[] UnitOfMeasurement;
    public int NumberOfSteps;
    public string[] CookingSteps;

    public Recipe(int numberOfIngredients, int numberOfSteps)//Constructor
    {
        NumberOfIngredients = numberOfIngredients;
        NameOfIngredient = new string[NumberOfIngredients];
        Quantity = new double[NumberOfIngredients];
        UnitOfMeasurement = new string[NumberOfIngredients];
        NumberOfSteps = numberOfSteps;
        CookingSteps = new string[NumberOfSteps];
    }

    public void CaptureIngredientDetails()//Method for capturing ingredients with details
    {
        Console.WriteLine("What is the name of your recipe?");
        NameOfRecipe = Console.ReadLine();
        Console.WriteLine($"How many ingredients are needed to prepare the {NameOfRecipe}?");
        NumberOfIngredients = Convert.ToInt32(Console.ReadLine());
        NameOfIngredient = new string[NumberOfIngredients]; 
        Quantity = new double[NumberOfIngredients];
        UnitOfMeasurement = new string[NumberOfIngredients];

        for (int i = 0; i < NumberOfIngredients; i++) //Loop for entering the ingredients according to the NumberOfIngredients
        {
            Console.WriteLine($"Enter the name for ingredient {i + 1}.");
            NameOfIngredient[i] = Console.ReadLine();
            Console.WriteLine($"Enter the quantity of ingredient {i + 1}.");
            Quantity[i] = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"Enter the unit of measurement for ingredient {i + 1}.");
            UnitOfMeasurement[i] = Console.ReadLine();
        }

        Console.WriteLine($"You have added {NumberOfIngredients} ingredients to your recipe! ");
    }

    public void DisplayIngredients() //Method to displays all ingredients
    {
        Console.WriteLine();
        Console.WriteLine("________________________________________________");
        Console.WriteLine("            Ingredients Captured: ");
        Console.WriteLine("________________________________________________");

        for (int i = 0; i < NumberOfIngredients; i++)
        {
            Console.WriteLine($"{NameOfIngredient[i]}, {Quantity[i]} {UnitOfMeasurement[i]}");
        }
        Console.WriteLine("________________________________________________");
        Console.WriteLine();
    }

    public void AddSteps() //Method to add steps to recipe
    {
        Console.WriteLine("How many steps would you like to add to your recipe?");
        NumberOfSteps = Convert.ToInt32(Console.ReadLine());
        CookingSteps = new string[NumberOfSteps];
        Console.WriteLine($"Add the {NumberOfSteps} steps required to prepare the recipe.");

        for (int i = 0; i < NumberOfSteps; i++)
        {
            Console.WriteLine($"Step {i + 1}");
            CookingSteps[i] = Console.ReadLine();
        }
    }

    public void DisplaySteps() //Method to display steps
    {
        Console.WriteLine("Here are the step to be followed to prepare the recipe: ");
        for (int i = 0; i < NumberOfSteps; i++)
        {
            Console.WriteLine($"Step {i + 1}");
            Console.WriteLine($"{CookingSteps[i]}");
        }
    }

    public void ScaleRecipe(double factor) //Method to scale recipe
    {
        for (int i = 0; i < NumberOfIngredients; i++)
        {
            Quantity[i] *= factor;
        }
        Console.WriteLine($"Recipe scaled by a factor of {factor}");
    }

    public void ResetQuantities(double factor) //Method to reset quantities
    {
        if (factor == 0)
        {
            Console.WriteLine("Error: Factor cannot be zero.");
            return;
        }

        for (int i = 0; i < NumberOfIngredients; i++)
        {
            Quantity[i] /= factor;
        }

        Console.WriteLine($"Quantities reset to original values (scaled by 1/{factor}).");
    }

    public void ClearData() //Method to clear all data
    {
        
        NameOfRecipe = "";
        NumberOfIngredients = 0;
        NameOfIngredient = null;
        Quantity = null;
        UnitOfMeasurement = null;
        NumberOfSteps = 0;
        CookingSteps = null;
        Console.WriteLine("All data cleared. Ready to enter a new recipe.");
    }
}

class Program
{
    private static void Main(string[] args)
    {
        bool exit = false;
        Recipe recipe = new Recipe(0, 0);

        while (!exit)
        {
            Console.WriteLine("________________________________________________");
            Console.WriteLine("                    MENU                        ");
            Console.WriteLine("________________________________________________");

            Console.WriteLine("1.) Capture the ingredients.");
            Console.WriteLine("2.) Display the ingredients required.");
            Console.WriteLine("3.) Add the steps needed to prepare the recipe.");
            Console.WriteLine("4.) Display the steps.");
            Console.WriteLine("5.) Scale the recipe.");
            Console.WriteLine("6.) Reset quantities.");
            Console.WriteLine("7.) Clear all data.");
            Console.WriteLine("8.) Exit");

            Console.WriteLine("________________________________________________");
            Console.WriteLine("             Choose an option!                  ");
            Console.WriteLine("________________________________________________");

            int MenuChoice = Convert.ToInt32(Console.ReadLine());

            switch (MenuChoice)
            {
                case 1:
                    recipe.CaptureIngredientDetails();
                    break;

                case 2:
                    recipe.DisplayIngredients();
                    break;

                case 3:
                    recipe.AddSteps();
                    break;

                case 4:
                    recipe.DisplaySteps();
                    break;

                case 5:
                    Console.WriteLine("Enter the scaling factor (0.5, 2, or 3): ");
                    double factor = Convert.ToDouble(Console.ReadLine());
                    recipe.ScaleRecipe(factor);
                    break;

                case 6:
                    Console.WriteLine("Enter the scaling factor (0.5, 2, or 3): ");
                    double resetFactor = Convert.ToDouble(Console.ReadLine());
                    recipe.ResetQuantities(resetFactor);
                    break;

                case 7:
                    recipe.ClearData();
                    break;

                case 8:
                    exit = true;
                    break;

                default:
                    Console.WriteLine("Invalid input! Please enter a valid number.");
                    break;
            }
        }
    }
}